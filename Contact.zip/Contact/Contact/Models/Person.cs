﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Contact.Models
{
    public class Person
    {
        public int ID { get; set; }
        public string Handle { get; set; }
        [Required]
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Home { get; set; }
        public string Address { get; set; }
        public string Postcode { get; set; }
        public string Instagram { get; set; }
        public string Twitter { get; set; }
        public string Facebook { get; set; }
        public string Tumblr { get; set; }
        public string Snapchat { get; set; }
        public string Linkedin { get; set; }
        public string Website { get; set; }
        public string Portfolio { get; set; }
        public string CompanyName { get; set; }
        public string CompanyEmail { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyMobile { get; set; }
        public byte[] Photo { get; set; } 
    }
}
